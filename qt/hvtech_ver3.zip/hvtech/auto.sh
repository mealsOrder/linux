#! /bin/bash

make clean
qmake hvtech.pro
make
